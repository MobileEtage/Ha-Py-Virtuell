
@interface SystemVolumeReceiver : NSObject
@end
